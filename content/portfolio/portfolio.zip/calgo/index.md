---
date: 2025-02-24
title: CAlgo
project:
  type: personal
  description: "C 기반 자료구조 및 알고리즘 구현(CMake, GTest, GBenchmark 사용)"
  github: https://github.com/nachiketa3299/CAlgo
---

* 자료구조, 알고리즘을 C로 구현하며 테스트, 성능 측정을 하는 토이 프로젝트
* https://github.com/nachiketa3299/CAlgo